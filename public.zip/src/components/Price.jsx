import React from 'react'

export default function Price() {
    return (
        <>
        <h1 className="head text-center py-5"> our <span>price</span> </h1>

        <div className="container d-flex flex-wrap justify-content-center ">
            <div class="card mb-lg-0 mb-3 me-lg-2" style={{width:"18rem"}}>
                <h5 class="card-header bg-blue text-white text-center py-3 fs-4">For Birthdays</h5>
                <div class="card-body text-center">
                    <h5 class="card-title my-3 fs-1">₹18,000.00</h5>
                    <ul className='list-unstyled  '>
                        <li><i className="fas fa-check my-3 bluecolor "></i> full services</li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> decorations </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> music and photos </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> food and drinks </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> invitation card </li>
                    </ul>
                    <a href="/" class="btn btn-secondary my-3">Check Out</a>
                </div>
            </div>
            <div class="card mb-lg-0 mb-3 card me-lg-2" style={{width:"18rem"}}>
                <h5 class="card-header bg-blue text-white text-center py-3 fs-4">For Weddings</h5>
                <div class="card-body text-center">
                    <h5 class="card-title my-3 fs-1">₹33,000.00</h5>
                    <ul className='list-unstyled  '>
                        <li><i className="fas fa-check my-3 bluecolor "></i> full services</li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> decorations </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> music and photos </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> food and drinks </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> invitation card </li>
                    </ul>
                    <a href="/" class="btn btn-secondary my-3">Check Out</a>
                </div>
            </div>
            <div class="card mb-lg-0 mb-3 card me-lg-2" style={{width:"18rem"}}>
                <h5 class="card-header bg-blue text-white text-center py-3 fs-4">For Concerts</h5>
                <div class="card-body text-center">
                    <h5 class="card-title my-3 fs-1">₹48,000.00</h5>
                    <ul className='list-unstyled  '>
                        <li><i className="fas fa-check my-3 bluecolor "></i> full services</li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> decorations </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> music and photos </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> food and drinks </li>
                        <li> <i className="fas fa-check my-3 bluecolor"></i> invitation card </li>
                    </ul>
                    <a href="/" class="btn btn-secondary my-3">Check Out</a>
                </div>
            </div>
            </div>
</>

    )}

