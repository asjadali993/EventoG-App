import React from 'react'

export default function Service() {
  return (
    <>
    <section className="service" id="service">

<h1 className="head text-center my-5 mx-5"> our <span >services</span> </h1>

<div className="container d-flex flex-wrap  ">

    <div className="box  ">
        <p className='icon m-auto'><i className="fas fa-map-marker-alt pt-3   "></i> </p>
        <h4 className='my-2'>venue selection</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

    <div className="box">
        <p className='icon m-auto'><i className="fas fa-envelope pt-3 "></i></p>
        <h4 className='my-2'>invitation card</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

    <div className="box">
        <p className='icon m-auto'><i className="fas fa-music pt-3"></i></p>
        <h4 className='my-2'>entertainment</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

    <div className="box">
    <p className='icon m-auto'> <i className="fas fa-utensils pt-3"></i></p>
        <h4 className='my-2'>food and drinks</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

    <div className="box">
    <p className='icon m-auto'> <i class="fas fa-film pt-3"></i></p>
        <h4 className='my-2'>photos and videos</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

    <div className="box">
    <p className='icon m-auto'><i className="fas fa-birthday-cake pt-3"></i></p>
        <h4 className='my-2'>custom food</h4>
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Porro, suscipit.</p>
    </div>

</div>

</section>
    </>
  )
}
