import React from 'react'

export default function Gallery() {
  return (
   <><section className="gallery" id="gallery">

   <h1 className="head text-center py-5">our <span>gallery</span></h1>

   <div className="container d-flex flex-wrap ">

       <div className="box">
           <img src="images/g-1.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-2.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-3.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-4.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-5.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-6.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-7.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-8.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

       <div className="box">
           <img src="images/g-9.jpg" alt=""/>
           <h3 className="title">photos and events</h3>
           <div className="icons">
               <a href="#" className="fas fa-heart"></a>
               <a href="#" className="fas fa-share"></a>
               <a href="#" className="fas fa-eye"></a>
           </div>
       </div>

   </div>

</section></>
  )
}
