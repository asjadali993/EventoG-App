import './App.css';
import About from './components/About';
import { Routes, Route, BrowserRouter as Router } from 'react-router-dom';

import Gallery from './components/Gallery';
import Home from './components/Home';
import Navbar from './components/Navbar';
import Price from './components/Price';
import Service from './components/Service';
import Review from './components/Review';
import ContactUs from './components/ContactUs';
import Footer from './components/Footer';

function App() {
  return (
    <Router>
      <>
        <Navbar/>
        
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Services" element={<Service />} />
          <Route path="/About" element={<About />} />
          <Route path="/Gallery" element={<Gallery />} />
          <Route path="/Price" element={<Price />} />
          <Route path="/Review" element={<Review />} />
          <Route path="/ContactUs" element={<ContactUs />} />
          
          
          {/* <Service/> */}
          
          {/* <About/> */}
          
          {/* <Gallery/> */}
          {/* <Price/> */}
          {/* <Review/> */}
          {/* <ContactUs/> */}
          
        </Routes>
        <Footer/>
      </>
    </Router>
  );
}

export default App;
